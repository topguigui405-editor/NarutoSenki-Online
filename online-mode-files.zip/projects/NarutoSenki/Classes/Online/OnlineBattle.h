#pragma once
// Sincronização da partida online.
//
// Modelo: cada celular roda o jogo inteiro (código original). O que muda:
//  - o herói de cada jogador humano é movido pelos comandos que ele envia (mover, atacar, usar/comprar gear);
//  - o HOST da sala manda, ~7x por segundo, a posição/vida de todos os heróis e a vida das torres,
//    e os demais celulares se corrigem em cima disso (sem "puxões" no herói do próprio jogador);
//  - fim de jogo é decidido só pelo host e avisado a todos;
//  - quem sai (ou perde a conexão) tem o herói assumido pela IA.
#include "Defines.h"
#include "Online/OnlineClient.h"
#include <map>
#include <string>
#include <vector>

class Hero;
class CharacterBase;

namespace online
{

class Battle
{
public:
	static Battle &get();

	bool active() const { return _active; }
	const StartInfo &info() const { return _info; }
	int mySlot() const { return _mySlot; }

	/** Lobby -> jogo: monta o elenco no modo de jogo certo e abre a tela de carregamento. */
	void launch(const StartInfo &info);

	// ---- ganchos do GameLayer / CharacterBase ----
	void registerHero(int slot, Hero *hero);
	void onGameStarted();
	void tick(float dt); // a cada 50 ms enquanto a partida não está pausada
	/** Chamado por GameLayer::checkTower. true = o online cuida do resultado (não decidir localmente). */
	bool decideGameOver(int konohaTowers, int akatsukiTowers);
	void onCharacterDead(CharacterBase *c);
	void shutdown(); // ao sair da partida (GameLayer::onLeft)

	// ---- entradas do jogador local (enviadas aos demais) ----
	void localMove(float x, float y);
	void localRelease();
	void localAttack(int abType);
	void localAttackRelease();
	void localGear(int gearType);
	void localBuyGear(int gearType);
	void localQuit(); // rendição / sair no meio da partida

private:
	struct RemoteInput
	{
		float dx = 0, dy = 0;
		bool hold = false; // botão de ataque normal segurado
	};

	void bindClient();
	void onRemoteInput(int slot, char kind, int a, int b);
	void onSnapshot(const std::string &payload);
	void onEvent(const std::string &payload);
	void onPlayerLeft(int slot);
	void onConnectionLost();
	void onOver(int winnerTeam);
	void sendSnapshot();
	void handOverToAI(int slot);
	Hero *heroOf(int slot);
	const SlotInfo *slotInfo(int slot) const;

	bool _active = false;
	bool _started = false;	// GameLayer já iniciou (antes disso mensagens da partida são ignoradas)
	bool _fallback = false; // conexão caiu / saiu da partida: segue sozinho contra a IA
	bool _overSent = false;
	bool _gameOverShown = false;
	StartInfo _info;
	int _mySlot = -1;
	int _myTeam = 0;
	int _tickCount = 0;
	std::vector<Hero *> _heroBySlot;
	std::vector<RemoteInput> _remote;

	// throttle do joystick local
	int _lastX = 0, _lastY = 0;
	bool _moving = false;
	double _lastMoveT = 0;

	// torres ausentes do último snapshot (para detectar torre destruída no host)
	std::map<int, int> _towerMissing;
};

} // namespace online
