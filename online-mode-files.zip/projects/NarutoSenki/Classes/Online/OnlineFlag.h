#pragma once
// Cabeçalho mínimo, incluído por Defines.h: diz se há uma partida online em andamento.
// (Enquanto houver, setRand() não troca a semente do sorteio, para que todos os celulares sorteiem igual.)
namespace online
{
bool isMatchActive();
}
