#include "OnlineClient.h"

#include <chrono>
#include <cstdlib>
#include <cstring>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
typedef SOCKET sock_t;
typedef int socklen_t_;
static const sock_t kInvalidSock = INVALID_SOCKET;
#else
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
typedef int sock_t;
typedef socklen_t socklen_t_;
static const sock_t kInvalidSock = -1;
#endif

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

namespace online
{

namespace
{

long long nowMs()
{
	using namespace std::chrono;
	return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

#ifdef _WIN32
struct WsaInit
{
	WsaInit()
	{
		WSADATA d;
		WSAStartup(MAKEWORD(2, 2), &d);
	}
} s_wsaInit;
void closeSock(sock_t s) { closesocket(s); }
void setNonBlocking(sock_t s)
{
	u_long m = 1;
	ioctlsocket(s, FIONBIO, &m);
}
bool wouldBlock() { return WSAGetLastError() == WSAEWOULDBLOCK; }
bool inProgress() { return WSAGetLastError() == WSAEWOULDBLOCK; }
bool interrupted() { return false; }
#else
void closeSock(sock_t s) { ::close(s); }
void setNonBlocking(sock_t s) { fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK); }
bool wouldBlock() { return errno == EAGAIN || errno == EWOULDBLOCK; }
bool inProgress() { return errno == EINPROGRESS; }
bool interrupted() { return errno == EINTR; }
#endif

// espera o socket ficar legível (read=true) ou gravável (read=false). >0 pronto, 0 timeout, <0 erro
int waitSock(sock_t s, bool read, int ms)
{
#ifndef _WIN32
	if (s >= FD_SETSIZE)
		return -1;
#endif
	fd_set fs, es;
	FD_ZERO(&fs);
	FD_ZERO(&es);
	FD_SET(s, &fs);
	FD_SET(s, &es);
	timeval tv;
	tv.tv_sec = ms / 1000;
	tv.tv_usec = (ms % 1000) * 1000;
	int r = select((int)s + 1, read ? &fs : nullptr, read ? nullptr : &fs, &es, &tv);
	if (r > 0 && FD_ISSET(s, &es))
		return -1;
	return r;
}

std::string sanitizeNick(const std::string &in)
{
	std::string out;
	for (char c : in)
	{
		if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_')
			out += c;
		if (out.size() >= 12)
			break;
	}
	return out.empty() ? "Ninja" : out;
}

int toInt(const std::string &s, int def = 0)
{
	if (s.empty())
		return def;
	char *end = nullptr;
	long v = strtol(s.c_str(), &end, 10);
	return (end && *end == '\0') ? (int)v : def;
}

// Chama uma CÓPIA do callback: ele pode trocar de tela e limpar/substituir os handlers enquanto roda.
template <class F, class... A>
void fire(const F &f, A &&...a)
{
	if (f)
	{
		F copy = f;
		copy(std::forward<A>(a)...);
	}
}

} // namespace

// ------------------------------------------------------------------------------------------------
// Conexão: uma thread cuida de DNS, connect, leitura e escrita. A thread principal só mexe nas filas.
// ------------------------------------------------------------------------------------------------
struct Client::Conn
{
	std::mutex mx;
	std::deque<std::string> in; // linhas para a thread principal ("!CONNECTED", "!CLOSED motivo", ...)
	std::string out;			// bytes pendentes de envio
	std::atomic<bool> stop{false};
	std::string host;
	int port = kDefaultPort;

	void pushIn(const std::string &s)
	{
		std::lock_guard<std::mutex> lk(mx);
		in.push_back(s);
	}
};

namespace
{

bool sendAll(sock_t fd, const std::string &data, const std::atomic<bool> &stop)
{
	size_t off = 0;
	long long deadline = nowMs() + 5000;
	while (off < data.size())
	{
		if (stop)
			return false;
		int n = (int)::send(fd, data.data() + off, (int)(data.size() - off), MSG_NOSIGNAL);
		if (n > 0)
		{
			off += (size_t)n;
			continue;
		}
		if (n < 0 && interrupted())
			continue;
		if (n < 0 && wouldBlock())
		{
			if (nowMs() > deadline)
				return false;
			waitSock(fd, false, 100);
			continue;
		}
		return false;
	}
	return true;
}

void ioMain(std::shared_ptr<Client::Conn> c)
{
	// 1) DNS + connect (com limite de 8 s)
	addrinfo hints;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	addrinfo *res = nullptr;
	std::string portStr = std::to_string(c->port);
	if (getaddrinfo(c->host.c_str(), portStr.c_str(), &hints, &res) != 0 || !res)
	{
		if (!c->stop)
			c->pushIn("!FAIL dns");
		return;
	}

	sock_t fd = kInvalidSock;
	long long deadline = nowMs() + 8000;
	for (addrinfo *ai = res; ai && fd == kInvalidSock && !c->stop; ai = ai->ai_next)
	{
		sock_t s = ::socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
		if (s == kInvalidSock)
			continue;
		setNonBlocking(s);
		bool ok = false;
		int r = ::connect(s, ai->ai_addr, (int)ai->ai_addrlen);
		if (r == 0)
		{
			ok = true;
		}
		else if (inProgress() || interrupted())
		{
			while (!c->stop && nowMs() < deadline)
			{
				int pr = waitSock(s, false, 100);
				if (pr > 0)
				{
					int err = 0;
					socklen_t_ len = sizeof(err);
					getsockopt(s, SOL_SOCKET, SO_ERROR, (char *)&err, &len);
					ok = (err == 0);
					break;
				}
				if (pr < 0)
					break;
			}
		}
		if (ok)
			fd = s;
		else
			closeSock(s);
	}
	freeaddrinfo(res);

	if (fd == kInvalidSock)
	{
		if (!c->stop)
			c->pushIn(nowMs() >= deadline ? "!FAIL timeout" : "!FAIL refused");
		return;
	}

	int one = 1;
	setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (const char *)&one, sizeof(one));
#ifdef SO_NOSIGPIPE
	setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, (const char *)&one, sizeof(one));
#endif
	c->pushIn("!CONNECTED");

	// 2) laço de leitura/escrita
	std::string rbuf;
	char tmp[4096];
	long long nextPing = nowMs() + 10000;
	std::string closeReason = "closed";
	while (!c->stop)
	{
		int pr = waitSock(fd, true, 15);
		if (pr < 0)
		{
			closeReason = "error";
			break;
		}
		if (pr > 0)
		{
			int n = (int)::recv(fd, tmp, sizeof(tmp), 0);
			if (n > 0)
			{
				rbuf.append(tmp, (size_t)n);
				size_t pos;
				while ((pos = rbuf.find('\n')) != std::string::npos)
				{
					std::string line = rbuf.substr(0, pos);
					rbuf.erase(0, pos + 1);
					if (!line.empty() && line.back() == '\r')
						line.pop_back();
					if (!line.empty())
						c->pushIn(line);
				}
				if (rbuf.size() > 8192)
				{
					closeReason = "overflow";
					break;
				}
			}
			else if (n == 0)
			{
				closeReason = "server_closed";
				break;
			}
			else if (!wouldBlock() && !interrupted())
			{
				closeReason = "error";
				break;
			}
		}

		long long now = nowMs();
		if (now >= nextPing)
		{
			nextPing = now + 10000;
			std::lock_guard<std::mutex> lk(c->mx);
			c->out += "PING " + std::to_string(now & 0x7fffffff) + "\n";
		}

		std::string data;
		{
			std::lock_guard<std::mutex> lk(c->mx);
			data.swap(c->out);
		}
		if (!data.empty() && !sendAll(fd, data, c->stop))
		{
			closeReason = "send_failed";
			break;
		}
	}

	closeSock(fd);
	if (!c->stop)
		c->pushIn("!CLOSED " + closeReason);
}

} // namespace

// ------------------------------------------------------------------------------------------------

Client::Client() {}

Client::~Client()
{
	if (_conn)
		_conn->stop = true; // a thread (desanexada) encerra sozinha
}

Client &Client::get()
{
	static Client instance;
	return instance;
}

std::vector<std::string> Client::split(const std::string &s, char sep)
{
	std::vector<std::string> out;
	size_t start = 0;
	while (true)
	{
		size_t p = s.find(sep, start);
		if (p == std::string::npos)
		{
			out.push_back(s.substr(start));
			break;
		}
		out.push_back(s.substr(start, p - start));
		start = p + 1;
	}
	return out;
}

void Client::clearHandlers()
{
	onConnected = nullptr;
	onDisconnected = nullptr;
	onError = nullptr;
	onRooms = nullptr;
	onJoinedRoom = nullptr;
	onRoom = nullptr;
	onLeftRoom = nullptr;
	onStart = nullptr;
	onInput = nullptr;
	onSnapshot = nullptr;
	onEvent = nullptr;
	onPlayerLeft = nullptr;
	onHostChanged = nullptr;
	onOver = nullptr;
}

void Client::connect(const std::string &host, int port, const std::string &nick)
{
	teardown("", false);
	_nick = sanitizeNick(nick);
	_conn = std::make_shared<Conn>();
	_conn->host = host;
	_conn->port = port > 0 ? port : kDefaultPort;
	_state = State::Connecting;
	_mySlot = _hostSlot = -1;
	_room = RoomState();
	auto conn = _conn;
	std::thread([conn]() { ioMain(conn); }).detach();
}

void Client::disconnect()
{
	teardown("", false);
}

void Client::teardown(const std::string &reason, bool notify)
{
	if (_conn)
	{
		_conn->stop = true;
		_conn.reset();
	}
	bool wasOnline = _state != State::Offline;
	_state = State::Offline;
	_mySlot = _hostSlot = -1;
	_room = RoomState();
	if (notify && wasOnline)
		fire(onDisconnected, reason);
}

void Client::send(const std::string &line)
{
	if (!_conn)
		return;
	std::lock_guard<std::mutex> lk(_conn->mx);
	_conn->out += line;
	_conn->out += '\n';
}

void Client::pump()
{
	auto conn = _conn;
	if (!conn)
		return;
	std::deque<std::string> batch;
	{
		std::lock_guard<std::mutex> lk(conn->mx);
		batch.swap(conn->in);
	}
	for (auto &line : batch)
	{
		if (_conn != conn)
			break; // um callback trocou/encerrou a conexão
		dispatch(line);
	}
}

// ---- comandos ----
void Client::listRooms() { send("LIST"); }
void Client::createRoom(int size) { send("CREATE " + std::to_string(size)); }
void Client::joinRoom(const std::string &id) { send("JOIN " + id); }
void Client::leaveRoom() { send("LEAVE"); }
void Client::setTeam(int team) { send("TEAM " + std::to_string(team)); }
void Client::setHero(const std::string &hero) { send("HERO " + hero); }
void Client::setReady(bool ready) { send(ready ? "READY 1" : "READY 0"); }
void Client::startMatch() { send("START"); }
void Client::sendInput(char kind, int a, int b)
{
	if (_state != State::InBattle)
		return;
	send(std::string("IN ") + kind + " " + std::to_string(a) + " " + std::to_string(b));
}
void Client::sendSnapshot(const std::string &payload)
{
	if (_state == State::InBattle && isHost())
		send("SNAP " + payload);
}
void Client::sendEvent(const std::string &payload)
{
	if (_state == State::InBattle && isHost())
		send("EVT " + payload);
}
void Client::sendOver(int winnerTeam)
{
	if (_state == State::InBattle && isHost())
		send("OVER " + std::to_string(winnerTeam));
}
void Client::quitBattle()
{
	if (_state == State::InBattle)
	{
		send("BACK");
		_state = State::Online;
		_mySlot = _hostSlot = -1;
	}
}

// ---- mensagens do servidor ----
void Client::dispatch(const std::string &line)
{
	if (line.empty())
		return;
	if (line[0] == '!')
	{
		if (line == "!CONNECTED")
		{
			send("HELLO " + std::to_string(kProtocolVersion) + " " + _nick);
		}
		else
		{
			auto f = split(line);
			teardown(f.size() > 1 ? f[1] : "closed", true);
		}
		return;
	}

	auto f = split(line);
	const std::string &cmd = f[0];

	if (cmd == "WELCOME")
	{
		_state = State::Online;
		fire(onConnected);
	}
	else if (cmd == "ERR")
	{
		std::string code = f.size() > 1 ? f[1] : "UNKNOWN";
		if (code == "PROTO")
		{
			teardown("PROTO", true);
			return;
		}
		fire(onError, code);
	}
	else if (cmd == "PONG")
	{
		int t = toInt(f.size() > 1 ? f[1] : "0");
		int now = (int)(nowMs() & 0x7fffffff);
		int rtt = now - t;
		if (rtt >= 0 && rtt < 60000)
			_pingMs = rtt;
	}
	else if (cmd == "ROOMS")
	{
		std::vector<RoomBrief> rooms;
		for (size_t i = 2; i < f.size(); i++)
		{
			auto p = split(f[i], ':');
			if (p.size() < 4)
				continue;
			RoomBrief b;
			b.id = p[0];
			b.size = toInt(p[1]);
			b.humans = toInt(p[2]);
			b.host = p[3];
			rooms.push_back(b);
		}
		fire(onRooms, rooms);
	}
	else if (cmd == "JOINED" && f.size() >= 4)
	{
		_state = State::InRoom;
		_room.id = f[1];
		_mySlot = toInt(f[2], -1);
		_room.size = toInt(f[3]);
		fire(onJoinedRoom);
	}
	else if (cmd == "ROOM")
	{
		parseRoom(f);
		fire(onRoom, _room);
	}
	else if (cmd == "LEFTROOM")
	{
		_state = State::Online;
		_mySlot = _hostSlot = -1;
		_room = RoomState();
		fire(onLeftRoom);
	}
	else if (cmd == "START")
	{
		parseStart(f);
	}
	else if (cmd == "IN" && f.size() >= 5)
	{
		if (!f[2].empty())
			fire(onInput, toInt(f[1], -1), f[2][0], toInt(f[3]), toInt(f[4]));
	}
	else if (cmd == "SNAP")
	{
		fire(onSnapshot, line.size() > 5 ? line.substr(5) : "");
	}
	else if (cmd == "EVT")
	{
		fire(onEvent, line.size() > 4 ? line.substr(4) : "");
	}
	else if (cmd == "LEFT" && f.size() >= 2)
	{
		fire(onPlayerLeft, toInt(f[1], -1), f.size() > 2 ? f[2] : "");
	}
	else if (cmd == "HOST" && f.size() >= 2)
	{
		_hostSlot = toInt(f[1], -1);
		fire(onHostChanged, _hostSlot);
	}
	else if (cmd == "OVER" && f.size() >= 2)
	{
		_state = State::InRoom;
		fire(onOver, toInt(f[1], 0));
	}
}

void Client::parseRoom(const std::vector<std::string> &f)
{
	if (f.size() < 5)
		return;
	_room.id = f[1];
	_room.size = toInt(f[2]);
	_room.state = f[3];
	_room.hostSlot = toInt(f[4], -1);
	_hostSlot = _room.hostSlot;
	_room.slots.clear();
	for (size_t i = 5; i < f.size(); i++)
	{
		auto p = split(f[i], ':');
		if (p.size() < 5)
			continue;
		SlotInfo s;
		s.slot = toInt(p[0]);
		s.team = toInt(p[1]);
		s.hero = p[2];
		s.ready = p[3] == "1";
		s.nick = p[4];
		s.human = (s.nick != "-" && s.nick != "COM");
		_room.slots.push_back(s);
	}
}

void Client::parseStart(const std::vector<std::string> &f)
{
	if (f.size() < 5)
		return;
	StartInfo info;
	info.seed = (uint32_t)strtoul(f[1].c_str(), nullptr, 10);
	info.size = toInt(f[2]);
	info.hostSlot = toInt(f[3], 0);
	for (size_t i = 4; i < f.size(); i++)
	{
		auto p = split(f[i], ':');
		if (p.size() < 5)
			continue;
		SlotInfo s;
		s.slot = toInt(p[0]);
		s.team = toInt(p[1]);
		s.hero = p[2];
		s.human = p[3] == "1";
		s.nick = p[4];
		info.slots.push_back(s);
	}
	_hostSlot = info.hostSlot;
	_state = State::InBattle;
	fire(onStart, info);
}

} // namespace online
