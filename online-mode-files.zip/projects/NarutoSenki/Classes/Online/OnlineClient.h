#pragma once
// Cliente do modo online (apenas C++ padrão + sockets; sem dependência do cocos2d-x).
// Toda a rede roda numa thread própria; as mensagens são entregues na thread principal
// quando alguém chama Client::pump() (feito a cada frame pelo OnlinePump).
#include <atomic>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace online
{

constexpr int kProtocolVersion = 1;
constexpr int kDefaultPort = 7777;

struct SlotInfo
{
	int slot = 0;
	int team = 0; // 0 = Konoha, 1 = Akatsuki
	std::string hero; // "-" = ainda sem escolha
	bool ready = false;
	bool human = false;
	std::string nick;
};

struct RoomState
{
	std::string id;
	int size = 0; // jogadores por time (1, 3 ou 4)
	std::string state; // "lobby" | "battle"
	int hostSlot = -1;
	std::vector<SlotInfo> slots;
};

struct RoomBrief
{
	std::string id;
	int size = 0;
	int humans = 0;
	std::string host;
};

struct StartInfo
{
	uint32_t seed = 0;
	int size = 0;
	int hostSlot = 0;
	std::vector<SlotInfo> slots; // elenco completo (humanos e IA), na ordem dos slots
};

class Client
{
public:
	enum class State
	{
		Offline,
		Connecting,
		Online, // conectado e identificado, fora de sala
		InRoom,
		InBattle
	};

	Client();
	~Client();
	Client(const Client &) = delete;
	Client &operator=(const Client &) = delete;

	static Client &get(); // instância usada pelo jogo

	// ---- conexão ----
	void connect(const std::string &host, int port, const std::string &nick);
	void disconnect();
	State state() const { return _state; }
	bool isConnected() const { return _state != State::Offline && _state != State::Connecting; }
	/** Processa mensagens recebidas e dispara os callbacks. Chamar na thread principal. */
	void pump();

	// ---- lobby ----
	void listRooms();
	void createRoom(int size);
	void joinRoom(const std::string &id);
	void leaveRoom();
	void setTeam(int team);
	void setHero(const std::string &hero); // "RANDOM" para sorteio
	void setReady(bool ready);
	void startMatch(); // só o host

	// ---- partida ----
	/** kind: M=mover(x*100,y*100) R=soltar joystick A=ataque(ABType) B=soltar ataque G=usar gear S=comprar gear */
	void sendInput(char kind, int a = 0, int b = 0);
	void sendSnapshot(const std::string &payload); // só o host
	void sendEvent(const std::string &payload);	   // só o host
	void sendOver(int winnerTeam);				   // só o host
	void quitBattle();

	// ---- informação ----
	int mySlot() const { return _mySlot; }
	int hostSlot() const { return _hostSlot; }
	bool isHost() const { return _mySlot >= 0 && _mySlot == _hostSlot; }
	int pingMs() const { return _pingMs; }
	const RoomState &room() const { return _room; }
	const std::string &nick() const { return _nick; }

	// ---- callbacks (sempre chamados dentro de pump()) ----
	std::function<void()> onConnected;
	std::function<void(const std::string &reason)> onDisconnected;
	std::function<void(const std::string &code)> onError;
	std::function<void(const std::vector<RoomBrief> &)> onRooms;
	std::function<void()> onJoinedRoom;
	std::function<void(const RoomState &)> onRoom;
	std::function<void()> onLeftRoom;
	std::function<void(const StartInfo &)> onStart;
	std::function<void(int slot, char kind, int a, int b)> onInput;
	std::function<void(const std::string &payload)> onSnapshot;
	std::function<void(const std::string &payload)> onEvent;
	std::function<void(int slot, const std::string &reason)> onPlayerLeft;
	std::function<void(int newHostSlot)> onHostChanged;
	std::function<void(int winnerTeam)> onOver;

	void clearHandlers();

	// uso interno / testes
	static std::vector<std::string> split(const std::string &s, char sep = ' ');

	struct Conn; // detalhe de implementação (thread de rede); público só para a thread poder usá-lo

private:
	void send(const std::string &line);
	void dispatch(const std::string &line);
	void parseRoom(const std::vector<std::string> &f);
	void parseStart(const std::vector<std::string> &f);
	void teardown(const std::string &reason, bool notify);

	std::shared_ptr<Conn> _conn;
	std::atomic<State> _state{State::Offline};
	std::string _nick;
	int _mySlot = -1;
	int _hostSlot = -1;
	int _pingMs = 0;
	RoomState _room;
	long long _lastPingMs = 0;
};

} // namespace online
