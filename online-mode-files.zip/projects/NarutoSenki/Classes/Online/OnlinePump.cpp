#include "Online/OnlinePump.h"
#include "Defines.h"
#include "Online/OnlineClient.h"

namespace online
{

namespace
{
class PumpTarget : public CCObject
{
public:
	void update(float) override { Client::get().pump(); }
};

PumpTarget *s_pump = nullptr;
} // namespace

void ensurePump()
{
	if (s_pump)
		return;
	s_pump = new PumpTarget(); // vive até o fim do processo (o agendador só guarda o ponteiro)
	Director::sharedDirector()->getScheduler()->scheduleUpdateForTarget(s_pump, 0, false);
}

} // namespace online
