#include "Online/OnlineLobbyLayer.h"
#include "Online/OnlineBattle.h"
#include "Online/OnlinePump.h"
#include "StartMenu.h"
#include <algorithm>
#include <cctype>
#include <set>

using online::Client;

namespace
{

const char *kFont = "Arial";
const ccColor3B kWhite = ccc3(255, 255, 255);
const ccColor3B kYellow = ccc3(255, 214, 64);
const ccColor3B kGray = ccc3(150, 150, 160);
const ccColor3B kRed = ccc3(255, 120, 120);
const ccColor3B kGreen = ccc3(130, 235, 130);
const ccColor3B kBlue = ccc3(120, 200, 255);

std::string errText(const std::string &code)
{
	if (code == "NO_ROOM")
		return "Sala não encontrada. Confira o código.";
	if (code == "FULL")
		return "Essa sala está cheia.";
	if (code == "STARTED")
		return "A partida dessa sala já começou.";
	if (code == "HERO_TAKEN")
		return "Esse herói já foi escolhido por outro jogador.";
	if (code == "NOT_READY")
		return "Ainda tem jogador que não está pronto.";
	if (code == "NOT_HOST")
		return "Só o dono da sala pode iniciar.";
	if (code == "TEAM_FULL")
		return "O outro time está cheio.";
	if (code == "SERVER_FULL")
		return "O servidor está lotado. Tente mais tarde.";
	if (code == "NEED_PLAYERS")
		return "É preciso mais de um jogador para iniciar.";
	return "Erro do servidor: " + code;
}

std::string disconnectText(const std::string &reason)
{
	if (reason == "dns")
		return "Não encontrei o servidor. Confira o endereço.";
	if (reason == "refused")
		return "Conexão recusada. Confira IP, porta e firewall.";
	if (reason == "timeout")
		return "Tempo esgotado ao conectar.";
	if (reason == "PROTO")
		return "Versão do servidor incompatível com este jogo.";
	if (reason == "server_closed" || reason == "closed")
		return "Conexão encerrada pelo servidor.";
	return "Conexão perdida (" + reason + ").";
}

std::string cleanNick(const std::string &in)
{
	std::string out;
	for (char c : in)
		if (std::isalnum((unsigned char)c) || c == '_')
			out += c;
	if (out.size() > 12)
		out.resize(12);
	return out.empty() ? "Ninja" : out;
}

std::string trim(const std::string &s)
{
	size_t a = s.find_first_not_of(" \t");
	size_t b = s.find_last_not_of(" \t");
	return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

} // namespace

Scene *OnlineLobbyLayer::scene()
{
	auto s = Scene::create();
	s->addChild(OnlineLobbyLayer::create());
	return s;
}

bool OnlineLobbyLayer::init()
{
	if (!Layer::init())
		return false;
	online::ensurePump();

	auto bg = LayerColor::create(ccc4(10, 14, 38, 255));
	addChild(bg, -10);

	auto ud = UserDefault::sharedUserDefault();
	_host = ud->getStringForKey("online_host", "");
	_nick = cleanNick(ud->getStringForKey("online_nick", "Ninja"));

	float W = winSize.width, H = winSize.height;
	_statusLabel = CCLabelTTF::create("", kFont, H / 24.0f, CCSizeMake(W * 0.94f, H * 0.1f),
									  kCCTextAlignmentCenter, kCCVerticalTextAlignmentCenter);
	_statusLabel->setPosition(Vec2(W / 2, H * 0.045f));
	addChild(_statusLabel, 50);

	showPage(Page::Connect);
	return true;
}

void OnlineLobbyLayer::onEnter()
{
	Layer::onEnter();
	bindClient();
	setKeypadEnabled(true);
	schedule(schedule_selector(OnlineLobbyLayer::autoRefreshRooms), 4.0f);
}

void OnlineLobbyLayer::onExit()
{
	unschedule(schedule_selector(OnlineLobbyLayer::autoRefreshRooms));
	setKeypadEnabled(false);
	// Se a partida está começando, quem cuida dos eventos agora é o online::Battle
	if (!_launching)
		Client::get().clearHandlers();
	Layer::onExit();
}

void OnlineLobbyLayer::keyBackClicked()
{
	if (_kbLayer)
		closeKeyboard(false);
	else
		goBackOneStep();
}

// ------------------------------------------------------------------------------------------------
// Interface
// ------------------------------------------------------------------------------------------------
CCMenuItem *OnlineLobbyLayer::addButton(const std::string &text, float cx, float cy, float w, float h,
										SEL_MenuHandler sel, int tag, bool enabled, bool primary)
{
	return addButtonTo(_menu, text, cx, cy, w, h, sel, tag, enabled, primary);
}

CCMenuItem *OnlineLobbyLayer::addButtonTo(CCMenu *menu, const std::string &text, float cx, float cy, float w,
										  float h, SEL_MenuHandler sel, int tag, bool enabled, bool primary)
{
	float H = winSize.height;
	float chars = (float)std::max<size_t>(text.size(), 6);
	float fs = std::min(H / 24.0f, w / (chars * 0.62f));
	auto label = CCLabelTTF::create(text.c_str(), kFont, fs, CCSizeMake(w, h), kCCTextAlignmentCenter,
									kCCVerticalTextAlignmentCenter);
	label->setColor(enabled ? kWhite : kGray);
	auto item = CCMenuItemLabel::create(label, this, sel);
	item->setPosition(Vec2(cx, cy));
	item->setTag(tag);
	ccColor4B color = !enabled ? ccc4(45, 45, 55, 220) : (primary ? ccc4(190, 100, 20, 240) : ccc4(40, 56, 110, 240));
	auto bg = LayerColor::create(color, w, h);
	item->addChild(bg, -1);
	item->setEnabled(enabled);
	menu->addChild(item);
	return item;
}

CCLabelTTF *OnlineLobbyLayer::addText(const std::string &text, float x, float y, float size,
									  const ccColor3B &color, float anchorX)
{
	auto label = CCLabelTTF::create(text.c_str(), kFont, size);
	label->setColor(color);
	label->setAnchorPoint(Vec2(anchorX, 0.5f));
	label->setPosition(Vec2(x, y));
	_content->addChild(label, 3);
	return label;
}

void OnlineLobbyLayer::setStatus(const std::string &text, bool isError)
{
	_status = text;
	_statusIsError = isError;
	if (_statusLabel)
	{
		_statusLabel->setString(text.c_str());
		_statusLabel->setColor(isError ? kRed : kYellow);
	}
}

void OnlineLobbyLayer::showPage(Page page)
{
	_page = page;
	if (_content)
	{
		_content->removeFromParentAndCleanup(true);
		_content = nullptr;
		_menu = nullptr;
	}
	_content = Node::create();
	addChild(_content, 1);
	_menu = CCMenu::create();
	_menu->setPosition(CCPointZero);
	_content->addChild(_menu, 2);

	switch (page)
	{
	case Page::Connect:
		buildConnect();
		break;
	case Page::Menu:
		buildMenu();
		break;
	case Page::Room:
		buildRoom();
		break;
	case Page::Heroes:
		buildHeroes();
		break;
	}
	if (_kbLayer)
		_menu->setEnabled(false); // teclado aberto: a página fica travada por baixo
}

void OnlineLobbyLayer::buildConnect()
{
	float W = winSize.width, H = winSize.height, fs = H / 18.0f;
	addText("JOGO ONLINE", W / 2, H - H * 0.1f, H / 11.0f, kYellow);

	addText("Servidor:", W * 0.06f, H * 0.66f, fs, kWhite, 0);
	addText(_host.empty() ? "(toque em Editar e digite o IP)" : _host, W * 0.27f, H * 0.66f, fs,
			_host.empty() ? kGray : kGreen, 0);
	addButton("Editar", W * 0.9f, H * 0.66f, W * 0.15f, H * 0.095f, menu_selector(OnlineLobbyLayer::onEditServer));

	addText("Apelido:", W * 0.06f, H * 0.50f, fs, kWhite, 0);
	addText(_nick, W * 0.27f, H * 0.50f, fs, kGreen, 0);
	addButton("Editar", W * 0.9f, H * 0.50f, W * 0.15f, H * 0.095f, menu_selector(OnlineLobbyLayer::onEditNick));

	addButton(_connecting ? "Conectando..." : "Conectar", W * 0.32f, H * 0.30f, W * 0.30f, H * 0.12f,
			  menu_selector(OnlineLobbyLayer::onConnect), 0, !_connecting, true);
	addButton("Voltar", W * 0.68f, H * 0.30f, W * 0.30f, H * 0.12f, menu_selector(OnlineLobbyLayer::onBackToMenu));

	addText("Exemplos:  192.168.0.10   ou   meuservidor.com:7777", W / 2, H * 0.17f, H / 26.0f, kGray);
}

void OnlineLobbyLayer::buildMenu()
{
	float W = winSize.width, H = winSize.height, fs = H / 20.0f;
	addText("Conectado como " + Client::get().nick(), W / 2, H - H * 0.07f, H / 14.0f, kGreen);

	float bw = W * 0.34f, bh = H * 0.10f;
	addText("Criar sala", W * 0.22f, H * 0.76f, fs, kYellow);
	addButton("1 x 1", W * 0.22f, H * 0.665f, bw, bh, menu_selector(OnlineLobbyLayer::onCreateRoom), 1);
	addButton("3 x 3", W * 0.22f, H * 0.545f, bw, bh, menu_selector(OnlineLobbyLayer::onCreateRoom), 3);
	addButton("4 x 4", W * 0.22f, H * 0.425f, bw, bh, menu_selector(OnlineLobbyLayer::onCreateRoom), 4);
	addButton("Entrar com código", W * 0.22f, H * 0.285f, bw, bh, menu_selector(OnlineLobbyLayer::onJoinByCode), 0,
			  true, true);

	addText("Salas abertas", W * 0.66f, H * 0.76f, fs, kYellow);
	if (_rooms.empty())
		addText("(nenhuma sala aberta agora)", W * 0.66f, H * 0.64f, H / 24.0f, kGray);
	for (size_t i = 0; i < _rooms.size() && i < 5; i++)
	{
		auto &r = _rooms[i];
		int max = r.size * 2;
		std::string t = r.id + "   " + std::to_string(r.size) + "x" + std::to_string(r.size) + "   " +
						std::to_string(r.humans) + "/" + std::to_string(max) + "   " + r.host;
		addButton(t, W * 0.66f, H * (0.665f - 0.105f * i), W * 0.5f, H * 0.09f,
				  menu_selector(OnlineLobbyLayer::onJoinListed), (int)i);
	}

	addButton("Atualizar lista", W * 0.66f, H * 0.13f, W * 0.30f, H * 0.09f, menu_selector(OnlineLobbyLayer::onRefresh));
	addButton("Desconectar", W * 0.22f, H * 0.13f, W * 0.30f, H * 0.09f, menu_selector(OnlineLobbyLayer::onDisconnect));
}

void OnlineLobbyLayer::buildRoom()
{
	auto &cl = Client::get();
	const auto &room = cl.room();
	float W = winSize.width, H = winSize.height;

	addText("SALA " + room.id + "   (" + std::to_string(room.size) + " x " + std::to_string(room.size) + ")", W / 2,
			H - H * 0.07f, H / 13.0f, kYellow);
	addText("Passe esse código para seus amigos entrarem", W / 2, H - H * 0.14f, H / 28.0f, kGray);
	addText("KONOHA", W * 0.27f, H - H * 0.22f, H / 17.0f, kBlue);
	addText("AKATSUKI", W * 0.73f, H - H * 0.22f, H / 17.0f, kRed);

	int row[2] = {0, 0};
	const online::SlotInfo *me = nullptr;
	for (auto &s : room.slots)
	{
		bool mine = s.slot == cl.mySlot();
		if (mine)
			me = &s;
		int r = row[s.team == 0 ? 0 : 1]++;
		float x = s.team == 0 ? W * 0.03f : W * 0.51f;
		float y = H - H * 0.30f - r * H * 0.085f;
		std::string line;
		ccColor3B color = kWhite;
		if (s.human)
		{
			line = std::string(mine ? "> " : "") + s.nick + " - " + (s.hero == "-" ? "sorteio" : s.hero) +
				   (s.ready ? "  [PRONTO]" : "");
			color = s.ready ? kGreen : (mine ? kYellow : kWhite);
		}
		else
		{
			line = "(vaga: entra uma IA)";
			color = kGray;
		}
		addText(line, x, y, H / 21.0f, color, 0);
	}

	float bw = W * 0.28f, bh = H * 0.10f;
	addButton("Trocar de time", W * 0.19f, H * 0.28f, bw, bh, menu_selector(OnlineLobbyLayer::onSwitchTeam));
	addButton("Escolher herói", W * 0.50f, H * 0.28f, bw, bh, menu_selector(OnlineLobbyLayer::onPickHero));
	bool ready = me && me->ready;
	addButton(ready ? "Cancelar pronto" : "Pronto", W * 0.81f, H * 0.28f, bw, bh,
			  menu_selector(OnlineLobbyLayer::onReady), 0, true, !ready);
	if (cl.isHost())
		addButton("Iniciar partida", W * 0.33f, H * 0.15f, W * 0.34f, bh, menu_selector(OnlineLobbyLayer::onStartMatch), 0,
				  true, true);
	else
		addText("Aguardando o dono da sala iniciar...", W * 0.33f, H * 0.15f, H / 26.0f, kGray);
	addButton("Sair da sala", W * 0.72f, H * 0.15f, W * 0.28f, bh, menu_selector(OnlineLobbyLayer::onLeaveRoom));
}

void OnlineLobbyLayer::buildHeroes()
{
	auto &cl = Client::get();
	float W = winSize.width, H = winSize.height;
	addText("Escolha seu herói", W / 2, H - H * 0.07f, H / 13.0f, kYellow);

	std::set<std::string> taken;
	for (auto &s : cl.room().slots)
		if (s.human && s.slot != cl.mySlot() && s.hero != "-")
			taken.insert(s.hero);

	const int cols = 6;
	float cw = (W - 24.0f) / cols, ch = H * 0.092f;
	for (size_t i = 0; i < kHeroNum; i++)
	{
		int r = (int)i / cols, c = (int)i % cols;
		float x = 12.0f + cw * (c + 0.5f);
		float y = H - H * 0.19f - r * (ch + 4.0f);
		bool isTaken = taken.count(kHeroList[i]) > 0;
		addButton(kHeroList[i], x, y, cw - 4.0f, ch, menu_selector(OnlineLobbyLayer::onHeroChosen), (int)i, !isTaken);
	}
	addButton("Aleatório", W * 0.30f, H * 0.11f, W * 0.28f, H * 0.095f, menu_selector(OnlineLobbyLayer::onHeroRandom));
	addButton("Voltar", W * 0.70f, H * 0.11f, W * 0.28f, H * 0.095f, menu_selector(OnlineLobbyLayer::onHeroesBack));
}

// ------------------------------------------------------------------------------------------------
// Teclado na tela
// ------------------------------------------------------------------------------------------------
void OnlineLobbyLayer::showKeyboard(Field field, const std::string &title, const std::string &initial, size_t maxLen)
{
	if (_kbLayer)
		return;
	_kbField = field;
	_kbBuffer = initial;
	_kbMax = maxLen;
	_kbUpper = (field == Field::RoomCode);
	_kbLetters.clear();

	float W = winSize.width, H = winSize.height;
	_kbLayer = LayerColor::create(ccc4(0, 0, 0, 230));
	addChild(_kbLayer, 100);

	auto t = CCLabelTTF::create(title.c_str(), kFont, H / 17.0f);
	t->setColor(kYellow);
	t->setPosition(Vec2(W / 2, H - H * 0.07f));
	_kbLayer->addChild(t, 1);

	_kbText = CCLabelTTF::create("_", kFont, H / 11.0f);
	_kbText->setColor(kGreen);
	_kbText->setPosition(Vec2(W / 2, H - H * 0.18f));
	_kbLayer->addChild(_kbText, 1);
	refreshKeyboardText();

	auto kbMenu = CCMenu::create();
	kbMenu->setPosition(CCPointZero);
	_kbLayer->addChild(kbMenu, 2);

	const char *rows[4] = {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm.:-_"};
	float kw = std::min(H * 0.105f, (W - 20.0f) / 11.0f), kh = H * 0.10f, gap = 3.0f;
	for (int r = 0; r < 4; r++)
	{
		std::string row = rows[r];
		float total = row.size() * (kw + gap) - gap;
		float x0 = (W - total) / 2 + kw / 2;
		float y = H - H * 0.31f - r * (kh + gap);
		for (size_t i = 0; i < row.size(); i++)
		{
			std::string s(1, row[i]);
			auto it = addButtonTo(kbMenu, s, x0 + i * (kw + gap), y, kw, kh, menu_selector(OnlineLobbyLayer::onKey),
								  (int)row[i]);
			if (std::isalpha((unsigned char)row[i]))
				_kbLetters.push_back((CCMenuItemLabel *)it);
		}
	}
	float y = H - H * 0.31f - 4 * (kh + gap);
	float bw = W * 0.2f;
	addButtonTo(kbMenu, "Aa", W * 0.14f, y, bw, kh, menu_selector(OnlineLobbyLayer::onKeyShift));
	addButtonTo(kbMenu, "Apagar", W * 0.37f, y, bw, kh, menu_selector(OnlineLobbyLayer::onKeyErase));
	addButtonTo(kbMenu, "Cancelar", W * 0.60f, y, bw, kh, menu_selector(OnlineLobbyLayer::onKeyCancel));
	addButtonTo(kbMenu, "OK", W * 0.84f, y, bw, kh, menu_selector(OnlineLobbyLayer::onKeyOk), 0, true, true);

	if (_menu)
		_menu->setEnabled(false);
}

void OnlineLobbyLayer::refreshKeyboardText()
{
	if (_kbText)
		_kbText->setString((_kbBuffer + "_").c_str());
}

void OnlineLobbyLayer::closeKeyboard(bool apply)
{
	if (!_kbLayer)
		return;
	_kbLayer->removeFromParentAndCleanup(true);
	_kbLayer = nullptr;
	_kbText = nullptr;
	_kbLetters.clear();

	if (apply)
	{
		auto ud = UserDefault::sharedUserDefault();
		switch (_kbField)
		{
		case Field::Server:
			_host = trim(_kbBuffer);
			ud->setStringForKey("online_host", _host);
			ud->flush();
			break;
		case Field::Nick:
			_nick = cleanNick(_kbBuffer);
			ud->setStringForKey("online_nick", _nick);
			ud->flush();
			break;
		case Field::RoomCode:
		{
			std::string code;
			for (char c : _kbBuffer)
				code += (char)std::toupper((unsigned char)c);
			if (code.size() == 4)
			{
				setStatus("Entrando na sala " + code + "...");
				Client::get().joinRoom(code);
			}
			else
			{
				setStatus("O código da sala tem 4 letras/números.", true);
			}
			break;
		}
		}
	}
	showPage(_page); // reconstrói a página (reabilita os botões)
}

void OnlineLobbyLayer::onKey(Ref *sender)
{
	char c = (char)((CCNode *)sender)->getTag();
	if (_kbField == Field::RoomCode || _kbUpper)
		c = (char)std::toupper((unsigned char)c);
	if (_kbBuffer.size() < _kbMax)
		_kbBuffer += c;
	refreshKeyboardText();
}

void OnlineLobbyLayer::onKeyErase(Ref *)
{
	if (!_kbBuffer.empty())
		_kbBuffer.pop_back();
	refreshKeyboardText();
}

void OnlineLobbyLayer::onKeyShift(Ref *)
{
	_kbUpper = !_kbUpper;
	for (auto item : _kbLetters)
	{
		char c = (char)item->getTag();
		std::string s(1, _kbUpper ? (char)std::toupper((unsigned char)c) : c);
		item->setString(s.c_str());
	}
}

void OnlineLobbyLayer::onKeyOk(Ref *) { closeKeyboard(true); }
void OnlineLobbyLayer::onKeyCancel(Ref *) { closeKeyboard(false); }

// ------------------------------------------------------------------------------------------------
// Botões
// ------------------------------------------------------------------------------------------------
void OnlineLobbyLayer::onEditServer(Ref *)
{
	showKeyboard(Field::Server, "Endereço do servidor (IP ou nome:porta)", _host, 40);
}

void OnlineLobbyLayer::onEditNick(Ref *)
{
	showKeyboard(Field::Nick, "Seu apelido (até 12 letras/números)", _nick, 12);
}

void OnlineLobbyLayer::onConnect(Ref *)
{
	std::string host = trim(_host);
	int port = online::kDefaultPort;
	size_t colon = host.rfind(':');
	if (colon != std::string::npos)
	{
		port = std::atoi(host.substr(colon + 1).c_str());
		host = host.substr(0, colon);
	}
	if (host.empty() || port <= 0 || port > 65535)
	{
		setStatus("Digite o endereço do servidor (ex.: 192.168.0.10).", true);
		return;
	}
	_connecting = true;
	setStatus("Conectando a " + host + ":" + std::to_string(port) + " ...");
	showPage(Page::Connect);
	Client::get().connect(host, port, _nick);
}

void OnlineLobbyLayer::onBackToMenu(Ref *) { leaveToStartMenu(); }

void OnlineLobbyLayer::onCreateRoom(Ref *sender)
{
	setStatus("");
	Client::get().createRoom(((CCNode *)sender)->getTag());
}

void OnlineLobbyLayer::onJoinByCode(Ref *) { showKeyboard(Field::RoomCode, "Código da sala", "", 4); }

void OnlineLobbyLayer::onJoinListed(Ref *sender)
{
	size_t idx = (size_t)((CCNode *)sender)->getTag();
	if (idx < _rooms.size())
	{
		setStatus("");
		Client::get().joinRoom(_rooms[idx].id);
	}
}

void OnlineLobbyLayer::onRefresh(Ref *) { Client::get().listRooms(); }

void OnlineLobbyLayer::onDisconnect(Ref *)
{
	Client::get().disconnect();
	_rooms.clear();
	_connecting = false;
	setStatus("");
	showPage(Page::Connect);
}

void OnlineLobbyLayer::onSwitchTeam(Ref *)
{
	auto &cl = Client::get();
	for (auto &s : cl.room().slots)
		if (s.slot == cl.mySlot())
			cl.setTeam(1 - s.team);
}

void OnlineLobbyLayer::onPickHero(Ref *) { showPage(Page::Heroes); }

void OnlineLobbyLayer::onHeroChosen(Ref *sender)
{
	size_t idx = (size_t)((CCNode *)sender)->getTag();
	if (idx < kHeroNum)
		Client::get().setHero(kHeroList[idx]);
	showPage(Page::Room);
}

void OnlineLobbyLayer::onHeroRandom(Ref *)
{
	Client::get().setHero("RANDOM");
	showPage(Page::Room);
}

void OnlineLobbyLayer::onHeroesBack(Ref *) { showPage(Page::Room); }

void OnlineLobbyLayer::onReady(Ref *)
{
	auto &cl = Client::get();
	for (auto &s : cl.room().slots)
		if (s.slot == cl.mySlot())
			cl.setReady(!s.ready);
}

void OnlineLobbyLayer::onStartMatch(Ref *)
{
	setStatus("");
	Client::get().startMatch();
}

void OnlineLobbyLayer::onLeaveRoom(Ref *) { Client::get().leaveRoom(); }

void OnlineLobbyLayer::autoRefreshRooms(float)
{
	if (_page == Page::Menu && Client::get().state() == Client::State::Online)
		Client::get().listRooms();
}

// ------------------------------------------------------------------------------------------------
// Eventos do servidor
// ------------------------------------------------------------------------------------------------
void OnlineLobbyLayer::bindClient()
{
	auto &c = Client::get();
	c.clearHandlers();
	c.onConnected = [this]()
	{
		_connecting = false;
		setStatus("");
		showPage(Page::Menu);
		Client::get().listRooms();
	};
	c.onDisconnected = [this](const std::string &reason)
	{
		_connecting = false;
		_rooms.clear();
		if (_kbLayer)
			closeKeyboard(false);
		showPage(Page::Connect);
		setStatus(disconnectText(reason), true);
	};
	c.onError = [this](const std::string &code) { setStatus(errText(code), true); };
	c.onRooms = [this](const std::vector<online::RoomBrief> &rooms)
	{
		_rooms = rooms;
		if (_page == Page::Menu && !_kbLayer)
			showPage(Page::Menu);
	};
	c.onJoinedRoom = [this]() { setStatus(""); };
	c.onRoom = [this](const online::RoomState &)
	{
		if (_kbLayer)
			closeKeyboard(false);
		if (_page != Page::Heroes) // na escolha de herói não reconstruímos a tela debaixo do dedo
			showPage(Page::Room);
	};
	c.onLeftRoom = [this]()
	{
		showPage(Page::Menu);
		Client::get().listRooms();
	};
	c.onStart = [this](const online::StartInfo &info)
	{
		if (_launching)
			return;
		_launching = true;
		if (_kbLayer)
			closeKeyboard(false);
		setStatus("Iniciando a partida...");
		online::Battle::get().launch(info);
	};
}

void OnlineLobbyLayer::goBackOneStep()
{
	switch (_page)
	{
	case Page::Heroes:
		showPage(Page::Room);
		break;
	case Page::Room:
		Client::get().leaveRoom();
		break;
	case Page::Menu:
		onDisconnect(nullptr);
		break;
	case Page::Connect:
		leaveToStartMenu();
		break;
	}
}

void OnlineLobbyLayer::leaveToStartMenu()
{
	SimpleAudioEngine::sharedEngine()->playEffect("Audio/Menu/cancel.ogg");
	Client::get().disconnect();
	Client::get().clearHandlers();
	auto menuScene = Scene::create();
	menuScene->addChild(StartMenu::create());
	Director::sharedDirector()->replaceScene(TransitionFade::create(1.0f, menuScene));
}
