#pragma once
// Liga o online ao laço principal do jogo: a cada frame entrega as mensagens recebidas.
namespace online
{
/** Idempotente. Pode ser chamado de qualquer tela antes de usar o Client. */
void ensurePump();
} // namespace online
