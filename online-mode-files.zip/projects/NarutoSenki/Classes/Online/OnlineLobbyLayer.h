#pragma once
// Tela do modo online: conectar ao servidor, criar/entrar em sala, escolher time e herói, iniciar.
// Feita só com camadas coloridas e texto (não depende de imagens novas) e com um teclado próprio na tela,
// porque o celular precisa digitar IP/apelido/código sem depender de caixa de texto nativa.
#include "Defines.h"
#include "Online/OnlineClient.h"
#include <string>
#include <vector>

class OnlineLobbyLayer : public Layer
{
public:
	static Scene *scene();
	CREATE_FUNC(OnlineLobbyLayer);

	bool init() override;
	void onEnter() override;
	void onExit() override;
	void keyBackClicked() override;

private:
	enum class Page
	{
		Connect,
		Menu,
		Room,
		Heroes
	};
	enum class Field
	{
		Server,
		Nick,
		RoomCode
	};

	// ---- construção da interface ----
	CCMenuItem *addButton(const std::string &text, float cx, float cy, float w, float h, SEL_MenuHandler sel,
						  int tag = 0, bool enabled = true, bool primary = false);
	CCMenuItem *addButtonTo(CCMenu *menu, const std::string &text, float cx, float cy, float w, float h,
							SEL_MenuHandler sel, int tag = 0, bool enabled = true, bool primary = false);
	CCLabelTTF *addText(const std::string &text, float x, float y, float size, const ccColor3B &color,
						float anchorX = 0.5f);
	void showPage(Page page);
	void buildConnect();
	void buildMenu();
	void buildRoom();
	void buildHeroes();
	void setStatus(const std::string &text, bool isError = false);

	// ---- teclado na tela ----
	void showKeyboard(Field field, const std::string &title, const std::string &initial, size_t maxLen);
	void closeKeyboard(bool apply);
	void refreshKeyboardText();

	// ---- botões ----
	void onEditServer(Ref *);
	void onEditNick(Ref *);
	void onConnect(Ref *);
	void onBackToMenu(Ref *);
	void onCreateRoom(Ref *);
	void onJoinByCode(Ref *);
	void onJoinListed(Ref *);
	void onRefresh(Ref *);
	void onDisconnect(Ref *);
	void onSwitchTeam(Ref *);
	void onPickHero(Ref *);
	void onHeroChosen(Ref *);
	void onHeroRandom(Ref *);
	void onHeroesBack(Ref *);
	void onReady(Ref *);
	void onStartMatch(Ref *);
	void onLeaveRoom(Ref *);
	void onKey(Ref *);
	void onKeyErase(Ref *);
	void onKeyShift(Ref *);
	void onKeyOk(Ref *);
	void onKeyCancel(Ref *);
	void autoRefreshRooms(float dt);

	void bindClient();
	void goBackOneStep();
	void leaveToStartMenu();

	Page _page = Page::Connect;
	Node *_content = nullptr; // tudo da página atual (recriado a cada showPage)
	CCMenu *_menu = nullptr;
	CCLabelTTF *_statusLabel = nullptr;
	std::string _status;
	bool _statusIsError = false;

	std::string _host;
	std::string _nick;
	bool _connecting = false;
	bool _launching = false;
	std::vector<online::RoomBrief> _rooms;

	// teclado
	Node *_kbLayer = nullptr;
	CCLabelTTF *_kbText = nullptr;
	Field _kbField = Field::Server;
	std::string _kbBuffer;
	size_t _kbMax = 24;
	bool _kbUpper = false;
	std::vector<CCMenuItemLabel *> _kbLetters;
};
