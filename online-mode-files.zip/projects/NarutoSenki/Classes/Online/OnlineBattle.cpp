#include "Online/OnlineBattle.h"
#include "GameMode/GameModeImpl.h"
#include "Core/Tower/Tower.hpp"
#include "GameLayer.h"
#include "HudLayer.h"
#include "LoadLayer.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>

extern int Cheats;

namespace online
{

namespace
{

double nowSec()
{
	using namespace std::chrono;
	return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

Group groupOfTeam(int team) { return team == 0 ? Group::Konoha : Group::Akatsuki; }

bool canAct(State s) { return s == State::IDLE || s == State::WALK || s == State::NATTACK; }

float dist(const Vec2 &a, float x, float y)
{
	float dx = x - a.x, dy = y - a.y;
	return std::sqrt(dx * dx + dy * dy);
}

} // namespace

bool isMatchActive() { return Battle::get().active(); }

Battle &Battle::get()
{
	static Battle instance;
	return instance;
}

const SlotInfo *Battle::slotInfo(int slot) const
{
	for (auto &s : _info.slots)
		if (s.slot == slot)
			return &s;
	return nullptr;
}

// Só devolve o herói se ele ainda estiver na partida (ponteiros antigos são descartados)
Hero *Battle::heroOf(int slot)
{
	if (slot < 0 || slot >= (int)_heroBySlot.size())
		return nullptr;
	auto layer = getGameLayer();
	Hero *h = _heroBySlot[slot];
	if (!layer || !h)
		return nullptr;
	auto &all = layer->_CharacterArray;
	return std::find(all.begin(), all.end(), h) != all.end() ? h : nullptr;
}

// ------------------------------------------------------------------------------------------------
// Início
// ------------------------------------------------------------------------------------------------
void Battle::launch(const StartInfo &info)
{
	auto &client = Client::get();
	_info = info;
	_mySlot = client.mySlot();
	_myTeam = 0;
	for (auto &s : info.slots)
		if (s.slot == _mySlot)
			_myTeam = s.team;

	size_t n = info.slots.size();
	_heroBySlot.assign(n, nullptr);
	_remote.assign(n, RemoteInput());
	_started = false;
	_fallback = false;
	_overSent = false;
	_gameOverShown = false;
	_tickCount = 0;
	_moving = false;
	_lastX = _lastY = 0;
	_towerMissing.clear();

	// O modo de jogo (mapa/torres/soldados) segue o tamanho da sala
	GameMode mode = info.size == 1 ? GameMode::OneVsOne : (info.size == 4 ? GameMode::FourVsFour : GameMode::Classic);
	s_GameMode = mode;
	auto handler = getGameModeHandler();
	handler->setOldCheats(Cheats);
	handler->init();

	// Ordem esperada pelo GameLayer::initHeros: jogador local, aliados, inimigos
	vector<HeroData> roster;
	auto add = [&](const SlotInfo &s)
	{
		HeroData d;
		d.name = s.hero;
		d.role = (s.slot == _mySlot) ? Role::Player : Role::Com;
		d.group = groupOfTeam(s.team);
		d.onlineSlot = s.slot;
		roster.push_back(d);
	};
	for (auto &s : info.slots)
		if (s.slot == _mySlot)
			add(s);
	for (auto &s : info.slots)
		if (s.team == _myTeam && s.slot != _mySlot)
			add(s);
	for (auto &s : info.slots)
		if (s.team != _myTeam)
			add(s);
	handler->initOnlineHeros(roster, groupOfTeam(_myTeam));

	_active = true;
	srand(info.seed); // todos os celulares partem da mesma semente
	bindClient();

	// mesma transição que SelectLayer::onGameStart faz
	SimpleAudioEngine::sharedEngine()->stopBackgroundMusic(true);
	SimpleAudioEngine::sharedEngine()->playEffect("Audio/Menu/confirm.ogg");
	Scene *loadScene = Scene::create();
	LoadLayer *loadLayer = LoadLayer::create();
	loadLayer->preloadAudio();
	loadScene->addChild(loadLayer);
	Director::sharedDirector()->replaceScene(TransitionFade::create(1.25f, loadScene));
}

void Battle::bindClient()
{
	auto &c = Client::get();
	c.clearHandlers();
	c.onInput = [this](int slot, char kind, int a, int b) { onRemoteInput(slot, kind, a, b); };
	c.onSnapshot = [this](const std::string &p) { onSnapshot(p); };
	c.onEvent = [this](const std::string &p) { onEvent(p); };
	c.onPlayerLeft = [this](int slot, const std::string &) { onPlayerLeft(slot); };
	c.onOver = [this](int team) { onOver(team); };
	c.onDisconnected = [this](const std::string &) { onConnectionLost(); };
}

void Battle::registerHero(int slot, Hero *hero)
{
	if (!_active || !hero || slot < 0)
		return;
	if (slot >= (int)_heroBySlot.size())
	{
		_heroBySlot.resize(slot + 1, nullptr);
		_remote.resize(slot + 1);
	}
	_heroBySlot[slot] = hero;
	auto si = slotInfo(slot);
	if (si && si->human && slot != _mySlot)
		hero->_isRemote = true; // sem IA: quem manda é o outro jogador
}

void Battle::onGameStarted()
{
	if (!_active)
		return;
	_started = true;
	_tickCount = 0;
	if (_fallback) // a conexão caiu durante o carregamento
		for (size_t i = 0; i < _heroBySlot.size(); i++)
			handOverToAI((int)i);
}

// ------------------------------------------------------------------------------------------------
// A cada 50 ms
// ------------------------------------------------------------------------------------------------
void Battle::tick(float)
{
	if (!_active || !_started || _fallback)
		return;
	_tickCount++;

	// 1) herói remoto: repete o "joystick segurado" e o "ataque segurado"
	for (size_t slot = 0; slot < _heroBySlot.size() && slot < _remote.size(); slot++)
	{
		Hero *h = heroOf((int)slot);
		if (!h || !h->_isRemote)
			continue;
		State st = h->getState();
		if (st != State::IDLE && st != State::WALK)
			continue;
		auto &in = _remote[slot];
		if (in.hold)
		{
			h->prepareRemoteAttack();
			h->attack(NAttack);
		}
		else if (in.dx != 0 || in.dy != 0)
		{
			h->walk(Vec2(in.dx, in.dy));
		}
	}

	// 2) host: estado autoritativo ~7x por segundo
	if (Client::get().isHost() && _tickCount % 3 == 0)
		sendSnapshot();
}

void Battle::sendSnapshot()
{
	auto layer = getGameLayer();
	if (!layer)
		return;
	std::string s = "S";
	char buf[96];
	for (size_t slot = 0; slot < _heroBySlot.size(); slot++)
	{
		Hero *h = heroOf((int)slot);
		if (!h)
			continue;
		bool dead = h->getState() == State::DEAD;
		snprintf(buf, sizeof(buf), " h%d:%d:%d:%u:%d:%d", (int)slot,
				 (int)std::lround(h->getPositionX()), (int)std::lround(h->getPositionY()),
				 (unsigned)h->getHP(), h->_isFlipped ? 1 : 0, dead ? 1 : 0);
		s += buf;
	}
	for (auto t : layer->_TowerArray)
	{
		snprintf(buf, sizeof(buf), " t%d:%u", t->getCharId(), (unsigned)t->getHP());
		s += buf;
	}
	Client::get().sendSnapshot(s);
}

// ------------------------------------------------------------------------------------------------
// Recebimento
// ------------------------------------------------------------------------------------------------
void Battle::onRemoteInput(int slot, char kind, int a, int b)
{
	if (!_active || !_started || _fallback || slot == _mySlot)
		return;
	Hero *h = heroOf(slot);
	if (!h || !h->_isRemote || slot >= (int)_remote.size())
		return;
	auto &in = _remote[slot];
	State st = h->getState();
	if (st == State::DEAD)
	{
		in = RemoteInput();
		return;
	}

	switch (kind)
	{
	case 'M':
		in.dx = a / 100.0f;
		in.dy = b / 100.0f;
		if (canAct(st))
			h->walk(Vec2(in.dx, in.dy));
		break;
	case 'R':
		in.dx = in.dy = 0;
		if (st == State::WALK)
			h->idle();
		break;
	case 'B':
		in.hold = false;
		break;
	case 'A':
	{
		ABType type = static_cast<ABType>(a);
		if (type == Item1)
		{
			h->_isCanItem1 = true; // quem enviou já respeitou a própria recarga
			h->setItem(type);
			break;
		}
		if (!canAct(st))
			break;
		if (type == NAttack)
			in.hold = true;
		// habilidades: o remetente já respeitou recarga/chakra no próprio celular
		if (type == SKILL1)
			h->_isCanSkill1 = true;
		else if (type == SKILL2)
			h->_isCanSkill2 = true;
		else if (type == SKILL3)
			h->_isCanSkill3 = true;
		else if (type == OUGIS1)
			h->_isCanOugis1 = true;
		else if (type == OUGIS2)
			h->_isCanOugis2 = true;
		if (type == NAttack || type == SKILL1 || type == SKILL2 || type == SKILL3 || type == OUGIS1 || type == OUGIS2)
		{
			h->prepareRemoteAttack();
			h->attack(type);
		}
		break;
	}
	case 'G':
		h->useGear(static_cast<GearType>(a));
		break;
	case 'S':
		h->setGear(static_cast<GearType>(a));
		break;
	default:
		break;
	}
}

void Battle::onSnapshot(const std::string &payload)
{
	if (!_active || !_started || _fallback)
		return;
	auto layer = getGameLayer();
	if (!layer)
		return;

	std::map<int, bool> seenTowers;
	for (auto &tok : Client::split(payload))
	{
		if (tok.size() < 2)
			continue;
		auto p = Client::split(tok.substr(1), ':');
		if (tok[0] == 'h' && p.size() >= 6)
		{
			int slot = std::atoi(p[0].c_str());
			float x = (float)std::atoi(p[1].c_str());
			float y = (float)std::atoi(p[2].c_str());
			uint32_t hp = (uint32_t)std::strtoul(p[3].c_str(), nullptr, 10);
			bool deadOnHost = p[5] == "1";
			Hero *h = heroOf(slot);
			if (!h || deadOnHost || h->getState() == State::DEAD)
				continue; // a morte chega por evento; renascimento acontece localmente

			if (hp > 0 && h->getHP() != hp)
			{
				h->setHPValue(hp);
				if (h->isPlayer())
					layer->setHPLose(h->getHpPercent());
			}

			// O herói do próprio jogador só é corrigido se estiver muito longe (evita "puxões");
			// os demais seguem o host de perto.
			bool mine = slot == _mySlot;
			float snapDist = mine ? 260.0f : 160.0f;
			float lerpMin = mine ? 120.0f : 10.0f;
			float k = mine ? 0.15f : 0.45f;
			Vec2 cur = h->getPosition();
			float d = dist(cur, x, y);
			if (d >= snapDist)
				h->setPosition(Vec2(x, y));
			else if (d > lerpMin)
				h->setPosition(Vec2(cur.x + (x - cur.x) * k, cur.y + (y - cur.y) * k));
			else
				continue;
			layer->reorderChild(h, -h->getPositionY());
		}
		else if (tok[0] == 't' && p.size() >= 2)
		{
			int id = std::atoi(p[0].c_str());
			uint32_t hp = (uint32_t)std::strtoul(p[1].c_str(), nullptr, 10);
			seenTowers[id] = true;
			for (auto t : layer->_TowerArray)
				if (t->getCharId() == id && hp > 0 && hp < t->getHP())
					t->setHPValue(hp);
		}
	}

	// torre que sumiu do snapshot do host foi destruída lá: destrói aqui também
	if (!seenTowers.empty())
	{
		auto towers = layer->_TowerArray; // cópia: dead() mexe na lista
		for (auto t : towers)
		{
			int id = t->getCharId();
			if (seenTowers.count(id))
			{
				_towerMissing[id] = 0;
				continue;
			}
			if (++_towerMissing[id] >= 2 && t->getState() != State::DEAD)
			{
				t->setHPValue(0);
				t->dead();
			}
		}
	}
}

void Battle::onEvent(const std::string &payload)
{
	if (!_active || !_started || _fallback)
		return;
	auto f = Client::split(payload);
	if (f.size() >= 2 && f[0] == "D")
	{
		Hero *h = heroOf(std::atoi(f[1].c_str()));
		if (h && h->getState() != State::DEAD)
		{
			h->setHPValue(0);
			h->dead();
		}
	}
}

void Battle::onPlayerLeft(int slot)
{
	if (!_active || slot == _mySlot)
		return;
	for (auto &s : _info.slots)
		if (s.slot == slot)
			s.human = false;
	if (_started)
		handOverToAI(slot);
}

void Battle::handOverToAI(int slot)
{
	Hero *h = heroOf(slot);
	if (!h || !h->_isRemote)
		return;
	h->_isRemote = false;
	if (slot < (int)_remote.size())
		_remote[slot] = RemoteInput();
	if (h->getState() == State::DEAD)
		return; // ao renascer o jogo religa a IA sozinho (Hero::reborn)
	if (h->getState() == State::WALK)
		h->idle();
	h->doAI();
}

void Battle::onConnectionLost()
{
	if (!_active || _fallback)
		return;
	_fallback = true; // sem rede: os outros jogadores viram IA e a partida segue offline
	if (_started)
	{
		for (size_t i = 0; i < _heroBySlot.size(); i++)
			handOverToAI((int)i);
		if (auto layer = getGameLayer())
			layer->checkTower(); // reavalia o fim de jogo agora que ele é local
	}
}

void Battle::onOver(int winnerTeam)
{
	if (!_active || !_started || _gameOverShown)
		return;
	auto layer = getGameLayer();
	if (!layer)
		return;
	_gameOverShown = true;
	layer->onGameOver(winnerTeam == _myTeam);
}

bool Battle::decideGameOver(int konohaTowers, int akatsukiTowers)
{
	if (!_active || _fallback)
		return false; // offline: decide como sempre
	if (Client::get().isHost() && !_overSent)
	{
		_overSent = true;
		Client::get().sendOver(akatsukiTowers == 0 ? 0 : 1); // time 0 = Konoha
	}
	(void)konohaTowers;
	return true; // todos (inclusive o host) encerram ao receber OVER
}

void Battle::onCharacterDead(CharacterBase *c)
{
	if (!_active || !_started || _fallback || !Client::get().isHost())
		return;
	for (size_t slot = 0; slot < _heroBySlot.size(); slot++)
	{
		if (_heroBySlot[slot] == c)
		{
			Client::get().sendEvent("D " + std::to_string(slot));
			return;
		}
	}
}

void Battle::shutdown()
{
	if (!_active)
		return;
	auto &c = Client::get();
	c.clearHandlers();
	c.disconnect(); // o servidor passa o herói para a IA e avisa os outros
	_active = false;
	_started = false;
	_fallback = false;
	_heroBySlot.clear();
	_remote.clear();
}

// ------------------------------------------------------------------------------------------------
// Entradas locais
// ------------------------------------------------------------------------------------------------
void Battle::localMove(float x, float y)
{
	if (!_active || !_started || _fallback)
		return;
	int ix = (int)std::lround(x * 100), iy = (int)std::lround(y * 100);
	double now = nowSec();
	bool changed = std::abs(ix - _lastX) + std::abs(iy - _lastY) >= 12;
	if ((changed || !_moving) && now - _lastMoveT >= 0.05)
	{
		Client::get().sendInput('M', ix, iy);
		_lastX = ix;
		_lastY = iy;
		_lastMoveT = now;
		_moving = true;
	}
}

void Battle::localRelease()
{
	if (!_active || !_started || _fallback || !_moving)
		return;
	Client::get().sendInput('R');
	_moving = false;
	_lastX = _lastY = 0;
}

void Battle::localAttack(int abType)
{
	if (!_active || !_started || _fallback)
		return;
	Client::get().sendInput('A', abType);
}

void Battle::localAttackRelease()
{
	if (!_active || !_started || _fallback)
		return;
	Client::get().sendInput('B');
}

void Battle::localGear(int gearType)
{
	if (!_active || !_started || _fallback)
		return;
	Client::get().sendInput('G', gearType);
}

void Battle::localBuyGear(int gearType)
{
	if (!_active || !_started || _fallback)
		return;
	Client::get().sendInput('S', gearType);
}

void Battle::localQuit()
{
	if (!_active || _fallback)
		return;
	_fallback = true; // a partir daqui joga sozinho; os outros passam a ver a IA no meu herói
	Client::get().quitBattle();
}

} // namespace online
